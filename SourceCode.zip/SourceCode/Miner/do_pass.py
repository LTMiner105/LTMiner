import os, re
import glob
import concurrent.futures

def preprocess_pass_result(raw_file, original_file):
    # merge_txt_files(raw_file)
    with open(os.path.join(raw_file, "rawseq.txt"), "r") as infile, open(original_file, "w+") as outfile:
        changed_lines = []
        for line in infile:
            cleaned_line = re.sub("func_call--", " \nfunc_call--", line)
            changed_lines.append(cleaned_line)

        for line in changed_lines:
            # 使用正则表达式清除行开头的空格
            cleaned_line = re.sub(r"^\s+", "", line)
            cleaned_line = re.sub(r"RET-__ubsan[\w]* ", "", cleaned_line)
            cleaned_line = re.sub(r"RET-llvm[\w\.]* ", "", cleaned_line)
            cleaned_line = re.sub(r"CHECK-__ubsan[\w]* ", "", cleaned_line)
            cleaned_line = re.sub(r"CHECK-llvm[\w\.]* ", "", cleaned_line)
            if not cleaned_line.startswith("func_call--"):
                cleaned_line = re.sub(r"__ubsan[\w]* ", "", cleaned_line)
                cleaned_line = re.sub(r"llvm[\w\.]* ", "", cleaned_line)
            # 如果行不为空，则写入输出文件
            if cleaned_line.strip():  # 检查行是否为空
                cleaned_line = re.sub(r"CHECK-", "[#CHK#]-", cleaned_line)
                cleaned_line = re.sub(r"RET-", "[#RT#]-", cleaned_line)
                cleaned_line = re.sub(r'\.\d+\b', '', cleaned_line)
                outfile.write(cleaned_line)

def find_all_bc_files(directory):
    bc_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".bc"):
                bc_files.append(os.path.join(root, file))
    return bc_files

def do_pass(pass_file, target_dir_list, output_dir, output_file, remainder):
    total = len(target_dir_list)
    count = 1
    for target_dir in target_dir_list:
        print("(" + str(remainder) + ")  " + str((count/total)*100) + "%   process pass to " + target_dir)
        cmd = " ".join(["opt", "-load", pass_file, "-enable-new-pm=0", "-disable-output", "-myDDGPass -outputdir=" + output_dir, "-outputfile=" + output_file, target_dir])
        # cmd = " ".join(["cd", target_dir, "; make CC=clang KFLAGS=\"-Xclang -load -Xclang", pass_file, "\" -j16"])
        os.system(cmd)
        count += 1

def mul_thread_do_pass(pass_file, kernel_dir, output_dir):
    if not os.path.exists(output_dir):
        # print(output_dir)
        os.mkdir(output_dir)
    bc_files = find_all_bc_files(kernel_dir)
    k, m = divmod(len(bc_files), 128)
    divided_list =  [bc_files[i * k + min(i, m):(i + 1) * k + min(i + 1, m)] for i in range(128)]
    # print(divided_list)

    # 创建线程池并行处理   
    with concurrent.futures.ThreadPoolExecutor(max_workers=128) as executor:
        future_to_key = {}
        for remainder in range(128):
            print("creat threads: " + str(remainder))
            sublist = divided_list[remainder]
            future = executor.submit(do_pass, pass_file, sublist, output_dir, str(remainder) + ".txt", remainder)
            future_to_key[future] = remainder

def merge_txt_files(directory):
    # 确保目录存在
    if not os.path.exists(directory):
        print(f"目录不存在: {directory}")
        return

    # 获取目录下所有 .txt 文件
    txt_files = glob.glob(os.path.join(directory, "*.txt"))

    # 排除 rawseq.txt 文件，避免重复写入
    txt_files = [f for f in txt_files if not f.endswith("rawseq.txt")]

    # 如果没有找到 .txt 文件，直接返回
    if not txt_files:
        print(f"目录下没有找到 .txt 文件: {directory}")
        return

    # 打开 rawseq.txt 文件，准备写入
    output_file = os.path.join(directory, "rawseq.txt")
    with open(output_file, "w", encoding="utf-8") as outfile:
        # 遍历所有 .txt 文件
        for txt_file in txt_files:
            with open(txt_file, "r", encoding="utf-8") as infile:
                # 读取文件内容并写入 rawseq.txt
                outfile.write(infile.read())
                outfile.write("\n")  # 每个文件内容之间加一个换行符

    print(f"所有 .txt 文件内容已汇总到: {output_file}")


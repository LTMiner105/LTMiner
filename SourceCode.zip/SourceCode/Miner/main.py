from do_pass import do_pass, preprocess_pass_result, merge_txt_files, mul_thread_do_pass
from mining import text_to_numbers, numbers_to_text
from pattern_filter import select_rules, ranking
from train_model import SE_Model, WE_Model
import os, torch
from sentence_transformers import SentenceTransformer

# 主程序
if __name__ == "__main__":
    proj_name = "20250521-nofilter-onranking"
    datashare_dir = "<your workspace path>/DataShare"
    code_dir = "<your workspace path>/Code/"
    pass_file = os.path.join(code_dir, "Pass/DDGParser/MyDDGPass.so")
    kernel_dir = "<your workspace path>/DataShare/LinuxKernel/linux-6.12.1"

    rules_result_dir = os.path.join(datashare_dir, "Rules", proj_name)
    if not os.path.exists(rules_result_dir):
        os.mkdir(rules_result_dir)
    pass_result_dir = os.path.join(datashare_dir, "PassResult")
    raw_file_dir = os.path.join(pass_result_dir, "testseq-0326-1")
    original_file = os.path.join(rules_result_dir, "originalseq.txt")
    restored_file = os.path.join(rules_result_dir, "restored.json")
    output_file = os.path.join(rules_result_dir, "rare_itemset.txt")
    input_file = os.path.join(rules_result_dir, "rare_only_input.txt")
    filtered_file = os.path.join(rules_result_dir, "filtered_file.json")
    embedding_file = os.path.join(rules_result_dir, "embedding.pkl")
    fpclose_dir = "<your workspace path>/Code/utils/fpclose/fim_closed"
    # for single test
    target_dir = "<your workspace path>/DataShare/test/bcm2835-camera.ll"
    se_model_name = "20250326-1-ft-e40-d300"
    we_model_name = "20250326-1-ft-e5-d100"
    we_context_model_name = "20250326-context-1-ft-e5-d100"
    se_model_dir = os.path.join(datashare_dir, "Model/SEM", se_model_name)
    we_funcname_model_dir = os.path.join(datashare_dir, "Model/WEM", we_model_name)
    we_item_model_dir = os.path.join(datashare_dir, "Model/WEM", we_context_model_name)
    context_embedding_file = os.path.join(rules_result_dir, "context_embedding_codeX-allcontext-nofilter9-0326.pkl")
    funcname_embedding_file = os.path.join(rules_result_dir, "funcname_embedding_FastTaxt-nofilter9-0326.pkl")
    item_embedding_file = os.path.join(rules_result_dir, "item_embedding_FastTaxt-nofilter9-0326.pkl")
    broken_pattern_list_file = os.path.join(rules_result_dir, 'broken_pattern_list-nofilter9-0326.pkl')
    result_file = os.path.join(rules_result_dir, 'result-nofilter9-0326-codeX-allcontext-withfuncname-filter_missing.html')
    support_filter = 9
    check_only = False

    pattern_min_sup = 2 # pmis
    pattern_min_len = 2  # pmil
    pattern_max_sup = 10 # pmas

    if not os.path.exists(rules_result_dir):
        os.mkdir(rules_result_dir)

    ################ preprocess #################
    mul_thread_do_pass(pass_file, kernel_dir, raw_file_dir)
    merge_txt_files(raw_file_dir)
    preprocess_pass_result(raw_file_dir, original_file)

    ################## mining ###################
    # 第一步：将文本转换为数字
    text_to_numbers(original_file, rules_result_dir, input_file, pattern_min_sup, pattern_max_sup)  # 请替换为你的输入文件名
    # 第二步：执行外部命令
    cmd = " ".join([fpclose_dir, input_file, str(pattern_min_sup), output_file])
    os.system(cmd)
    # 第三步：将输出转换回文本
    numbers_to_text(output_file, restored_file, rules_result_dir)

    ################ train model #################
    my_se_model = SE_Model(40, 300)
    my_se_model.prepare_train_data(se_model_dir, original_file)
    my_se_model.train(se_model_dir)

    my_we_model = WE_Model()
    my_we_model.prepare_data(we_funcname_model_dir, original_file)
    my_we_model.train(we_funcname_model_dir, "func_name")

    my_we_model = WE_Model()
    my_we_model.prepare_context_data(we_item_model_dir, original_file)
    my_we_model.train(we_item_model_dir, "context")
    
    # load model

    se_model = None
    # 查看是否有缓存的WE嵌入结果
    we_funcname_model = WE_Model()
    we_funcname_model.load_model(we_funcname_model_dir)
    we_item_model = we_funcname_model


    # ################### ranking ###################
    ranking(restored_file, rules_result_dir, se_model_dir, we_funcname_model_dir, we_item_model_dir, support_filter, check_only, result_file, 
            context_embedding_file, funcname_embedding_file, item_embedding_file, broken_pattern_list_file, False, True, se_model, we_funcname_model, we_item_model)
 
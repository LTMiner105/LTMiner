import os, json, time, copy
from statistics import mean
from sentence_transformers import SentenceTransformer, util
import pickle
import numpy as np
from train_model import SE_Model, WE_Model
import concurrent.futures
from collections import defaultdict
# import Levenshtein
import re
from nltk.corpus import wordnet as wn
from nltk.stem import WordNetLemmatizer
import nltk
from datasets import load_dataset
import wordsegment
import torch

def split_function_name(name):
    """拆分函数名为单词列表，处理驼峰和下划线"""
    # 处理驼峰式：在大写字母前插入空格
    name = re.sub(r'([a-z])([A-Z])', r'\1 \2', name)
    # 替换下划线和转为小写
    name = name.replace('_', ' ').lower()
    name_list = name.split()
    return name_list

def get_lemma(word):
    # 初始化词形还原器
    lemmatizer = WordNetLemmatizer()
    """获取单词的动词原形（假设函数名中的动词更关键）"""
    return lemmatizer.lemmatize(word, pos='v')

def get_antonyms(word, antonyms_dict):
    """通过WordNet获取反义词集合"""
    antonyms = set()

    for pair in antonyms_dict:
        if word == pair[0]:
            antonyms.add(pair[1])
        if word == pair[1]:
            antonyms.add(pair[0])

    for syn in wn.synsets(word):
        for lemma in syn.lemmas():
            for antonym in lemma.antonyms():
                ant_word = antonym.name().lower()
                ant_lemma = get_lemma(ant_word)
                antonyms.add(ant_lemma)
    return antonyms

def has_antonyms(func1, func2, antonyms_dict):
    """主函数：判断两个函数名是否包含反义词"""
    # 加载negative_prefix_list
    negative_prefix_list = []

    # 拆分并标准化单词
    words1 = [get_lemma(word) for word in split_function_name(func1)]
    words2 = [get_lemma(word) for word in split_function_name(func2)]

    # 检查WordNet反义词
    full_segment_list_1 = []
    for word in words1:
        full_segment_list_1 += wordsegment.segment(word)
    full_segment_list_2 = []
    for word in words2:
        full_segment_list_2 += wordsegment.segment(word)

    for word in words1:
        wordsegment_list = wordsegment.segment(word)
        antonyms = set()
        if wordsegment_list[0] in negative_prefix_list:
            antonyms.add(word[len(wordsegment_list[0]):])
        for subword in wordsegment_list:
            antonyms.update(get_antonyms(subword, antonyms_dict))
            if any(ant in full_segment_list_2 for ant in antonyms):
                return True

    for word in words2:
        wordsegment_list = wordsegment.segment(word)
        antonyms = set()
        if wordsegment_list[0] in negative_prefix_list:
            antonyms.add(word[len(wordsegment_list[0]):])
        for subword in wordsegment_list:
            antonyms.update(get_antonyms(subword, antonyms_dict))
            if any(ant in full_segment_list_1 for ant in antonyms):
                return True
    return False

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def get_lift_similarity():
    pass

def embed_word(we_model, target_word, embedding_result_dict, has_embedded):
    if not has_embedded and target_word not in embedding_result_dict.keys():
        target_word_v = np.array(we_model.embedding_single_word(target_word))
        embedding_result_dict[target_word] = target_word_v
    else:
        target_word_v = embedding_result_dict[target_word]
    return target_word_v

def embed_words(we_model, target_list):
    vec_list = []
    for target in target_list:
        wv = we_model.embedding_single_word(target)
        vec_list.append(wv)
    return vec_list

def embedding_seq(se_model, target_list, se_model_dir, embed_batch=None):
    try:
        vec_list = se_model.encode(target_list, convert_to_tensor=True, normalize_context_embedding_list=True)
        vec_list_cpu = vec_list.cpu()
    except:
        vec_list_cpu = np.zeros((len(target_list), 1024))
        print("embedding fail")
    # vec_list = []
    # for target in target_list:
    #     vec_text = se_model.embed_single_seq(se_model_dir, target, embed_batch)
    #     vec = np.array([float(i) for i in vec_text])
    #     vec_list.append(vec)

    return vec_list_cpu

def get_cos_similarity(se_model, vio_context, pattern_context_dict, se_model_dir, we_funcname_model, vio_id, 
                       context_embedding_dict, has_context_embedded, funcname_embedding_dict, 
                       has_funcname_embedded, vio_func_name, sid2func_name):
    max_global_sim = -100
    max_local_sim = 0
    max_miss_sim = 0
    pattern_context_list = []
    pattern_caller_name_list = []
    nearlest_pattern = ""
    nearlest_func_name = ""
            
    missing_pattern_item_embedding_list = []
    pattern_context_item_embedding_list = []
    pattern_context_item_embedding_list_list = []
    
    for k, v in pattern_context_dict.items():
        pattern_context_list.append(v)
        pattern_caller_name_list.append(sid2func_name[k])

    # print(pattern_context_list + [vio_context])
    # 嵌入 context
    if not has_context_embedded:
        context_embedding_list = embedding_seq(se_model, pattern_context_list + [vio_context], se_model_dir, vio_id%128)
        context_embedding_dict[vio_id] = context_embedding_list
    else:
        context_embedding_list = context_embedding_dict[vio_id]

    # 嵌入 item
    if not has_funcname_embedded:
        vio_funcname_v = np.array(we_funcname_model.embedding_single_word(vio_func_name))
        sup_funcname_v_list = []
        for sup_funcname in pattern_caller_name_list:
            sup_funcname_v_list.append(np.array(we_funcname_model.embedding_single_word(sup_funcname)))
        funcname_embedding_dict[vio_id] = [vio_funcname_v, sup_funcname_v_list]
    else:
        vio_funcname_v = funcname_embedding_dict[vio_id][0]
        sup_funcname_v_list = funcname_embedding_dict[vio_id][1]
    # print(str(vio_id) + " :embedding done")


    # 计算 global similarity
    context_distance_list = []
    vio_concate_vec = np.concatenate((context_embedding_list[-1], vio_funcname_v))
    # print(len(vio_concate_vec))
    for i in range(len(context_embedding_list) - 1):
        sup_concate_vec = np.concatenate((context_embedding_list[i], sup_funcname_v_list[i]))
        sim = util.cos_sim(vio_concate_vec, sup_concate_vec) * 100  # 按需缩放
        cos_sim = sim.item()
        context_distance_list.append(cos_sim)
        if max_global_sim < cos_sim:
            max_global_sim = cos_sim
            nearlest_pattern = pattern_context_list[i]
            nearlest_func_name = pattern_caller_name_list[i]

    best_score = max_global_sim

    # avg_sim = mean(distance_list)
    return best_score, nearlest_pattern, nearlest_func_name


def process_list(sublist, se_model, se_model_dir, we_funcname_model, context_embedding_dict, has_context_embedded, 
                 funcname_embedding_dict, has_funcname_embedded, sid2func_name, remainder):
    # torch.cuda.set_device(remainder)
    # 查看是否有缓存的SE嵌入结果
    se_model = SentenceTransformer("Salesforce/SFR-Embedding-Code-400M_R", trust_remote_code=True)
    se_model = se_model.to(f"cuda:{remainder+1}") 
    se_model = torch.nn.DataParallel(se_model)
    se_model = se_model.module

    result_list = []
    for result in sublist:
        vio_context = result["vio_context"]
        pattern_context_dict = result["pattern_context_dict"]
        vio_func_name = result["violation info"][0]
        vio_id = result["vio_id"]
        print("vio_id:" + str(vio_id))
        result["rank_score"], result["nearlest_pattern"], result["nearlest_func_name"] = get_cos_similarity(se_model, vio_context, pattern_context_dict, se_model_dir, we_funcname_model, vio_id, context_embedding_dict, 
                                                                                                            has_context_embedded, funcname_embedding_dict, has_funcname_embedded, vio_func_name, sid2func_name)
        # result["rank_score"], result["nearlest_pattern"], result["nearlest_func_name"] = 0, [], ""
        result_list.append(result)
    return result_list


def select_rules(pattern_min_len, restored_file, filtered_file):
    with open(restored_file, "r") as f:
        data = json.load(f)

    filtered_result = []
    for item in data:
        pattern_len = item["pattern_length"]
        
        if pattern_len < pattern_min_len:
            continue
        filtered_result.append(item)

    with open(filtered_file, 'w') as f:
        json.dump(filtered_result, f, indent=4, ensure_ascii=False)


def write_result(check_only, f, broken_pattern_list, do_filter, do_ranking):
    # 为排除违例加载数据集：
    # 加载数据集（Hugging Face 会自动缓存数据）
    ds = load_dataset("KnutJaegersberg/antonym_dataset_fasttext_variances")
    antonyms_dict = []
    for item in ds["train"]:
        antonyms_dict.append([item["V1"], item["V2"]])
    # 加载wordnet
    try:
        wn.synsets('test')
    except LookupError:
        nltk.download('wordnet')
    # 加载wordsegment
    wordsegment.load()

    count = 0
    for result in broken_pattern_list:
        # if result["has_same_return"]:
        #     continue
        info = result["violation info"]
        vio_func_name = info[0]
        vio_info_list = info[1]
        # print(vio_info_list)

        if check_only and not vio_info_list[1] == "[#CHK#]-" + vio_info_list[0]:
            continue
        # filter 4
        if (do_filter):
            if(has_antonyms(vio_func_name, result["nearlest_func_name"], antonyms_dict)):
                result["reason"] = "antonyms function name"
            
        if result["reason"] == "":
            count += 1
            f.write("\n<br>vio-rank: " + str(count))
        f.write("\n<br>func_level_support: " + str(result["func level support"]))
        f.write("\n<br>func_level_confidence: " + str(result["func level confidence"]))
        f.write("\n<br>pattern violation count: " + str(result["pattern violation count"]))
        if (not do_ranking):
            f.write("\n<br>lift: " + str(result["lift"]))
            f.write("\n<br>all_conf: " + str(result["all_conf"]))
        if (do_ranking):
            f.write("\n<br>rank_score: " + str(result["rank_score"]))
        f.write("\n<br>pattern_length: " + str(result["pattern_length"]))
        f.write("\n<br>pattern_support: " + str(result["pattern_support"]))
        f.write("\n<br>pattern_covered_func: " + ", ".join(result["pattern_covered_func"]) + ",")
        f.write("\n<br>pattern: " + ", ".join(result["pattern"]) + ",")
        f.write("\n<br>violation_info:")
        f.write("\n<br># violation: <a target=\"_blank\" href=\"https://elixir.bootlin.com/linux/v6.13.1/A/ident/" + vio_func_name + "\">Code Reference</a>")

        if check_only:
            f.write("\n<br>   missing_check: " + vio_info_list[1] + "    pair: " + vio_info_list[0])
        else:
            try:
                f.write("\n<br>   missing_pattern (" + str(len(result["filtered_missing_pattern_part"])) + ") :"+ ", ".join(result["filtered_missing_pattern_part"]) + "," + 
                        "\n<br>   covered_pattern: "+ ", ".join(vio_info_list[2]) + ",")
                if len(result["replaced_pattern"]):
                    replaced_pattern_str = ""
                    for ms_word, vc_word in result["replaced_pattern"].items():
                        replaced_pattern_str += ms_word + "(" + vc_word + "), "
                        
                    f.write("\n<br>   replaced_pattern: " + replaced_pattern_str + ",")

                f.write("\n<br><br>   vio_func_name: " + vio_func_name)
                if (do_ranking):
                    f.write("\n<br>   sup_func_name: " + result["nearlest_func_name"])
                    f.write("\n<br>   # most_similar_sup_func:<a target=\"_blank\" href=\"https://elixir.bootlin.com/linux/v6.13.1/A/ident/" + result["nearlest_func_name"] + "\">Code Reference</a>" + 
                            "\n<br>   vio_context: " + ", ".join(vio_info_list[1]) + "," + 
                            "\n<br>   sup_context: " + ", ".join(result["nearlest_pattern"].split()) + "," + 
                            "\n<br>   reason: " + result["reason"] )
                f.write("\n<br>\n<br>")
            except:
                pass
                # print(type(str(len(vio_info_list[0]))), type(" ".join(vio_info_list[0])), type(vio_func_name), type(" ".join(vio_info_list[2])), type(" ".join(vio_info_list[1])), type(result["nearlest_pattern"]), type(result["nearlest_func_name"]))
                # print(result["locations"], result["pattern_context_dict"])
        f.write("\n<br>")




def gen_rules(pattern):
    rule_list = []
    return rule_list


def ranking(restored_file, rules_result_dir, se_model_dir, we_funcname_model_dir, we_item_model_dir, support_filter, 
            check_only=True, result_file="", context_embedding_file="", funcname_embedding_file="", item_embedding_file="", 
            broken_pattern_list_file="", do_filter=True, do_ranking=True, se_model=None, we_funcname_model=None, we_item_model=None):
    import time

    # 加载基础数据
    with open(restored_file, "r") as f:
        restored_mining_result = json.load(f)
    with open(os.path.join(rules_result_dir, "sid2func_name.json"), "r") as f:
        sid2func_name = json.load(f)
    with open(os.path.join(rules_result_dir, 'word2sid.json'), 'r') as f:
        word2sid = json.load(f)
    with open(os.path.join(rules_result_dir, 'sid2retlist.json'), 'r') as f:
        sid2retlist = json.load(f)
    with open(os.path.join(rules_result_dir, 'sid2slice.json'), 'r') as f:
        sid2slice = json.load(f)    
    slice_sum = len(sid2func_name)
    
    # 查看是否有缓存的SE嵌入结果
    if os.path.exists(context_embedding_file):
        with open(context_embedding_file, "rb") as f:
            context_embedding_dict = pickle.load(f)
        has_context_embedded = True
        se_model = None
    else:
        has_context_embedded = False
        context_embedding_dict = {}

    # 查看是否有缓存的WE嵌入结果
    if os.path.exists(funcname_embedding_file):
        with open(funcname_embedding_file, "rb") as f:
            funcname_embedding_dict = pickle.load(f)
        has_funcname_embedded = True
        we_funcname_model = None
    else:
        has_funcname_embedded = False
        funcname_embedding_dict = {}

    # 查看是否有缓存的WE_context_item嵌入结果(多了check)
    if os.path.exists(item_embedding_file):
        with open(item_embedding_file, "rb") as f:
            item_embedding_dict = pickle.load(f)
        has_item_embedded = True
        we_item_model = None
    else:
        has_item_embedded = False
        item_embedding_dict = {}


    # if os.path.exists(rules_file):
    #     with open(rules_file, "rb") as f:
    #         rules_list = pickle.load(f)
    #     has_gen_rules = True
    # else:
    #     has_gen_rules = False
    #     rules_list = []
    
    print("model loaded")
    T_start = time.time()

    # 遍历挖掘结果，找出所有的违例
    if os.path.exists(broken_pattern_list_file):
        with open(broken_pattern_list_file, "rb") as bplf:
            broken_pattern_list = pickle.load(bplf)
    # if 0:
    #     pass
    else:    
        broken_pattern_list = []
        vio_id = 0
        pattern_id = 0
        total = len(restored_mining_result)
        for result in restored_mining_result:

            print("seeking violations: " + str((pattern_id/total) * 100) + "%  total: " + str(total) + "    current: " + str(pattern_id))
            pattern_id += 1
            result["reason"] = ""
            
            # if vio_id > 100:
            #     break
            # pattern_len = result["pattern_length"]
            # pattern_sup = result["pattern_support"]
            locations = result["locations"]
            pattern_list = result["pattern"]

            # 生成rules
            # if not has_gen_rules:
            #     rules_list += gen_rules(pattern_list)

            # 看是否有check，并记录check信息
            has_func_check = False
            check_loc_dict = {}
            check_func_list = []
            for word in pattern_list:
                if word.startswith("[#CHK#]-"):
                    has_func_check = True
                    check_loc_dict[word] = word2sid[word]
                    check_func_list.append(word[len("[#CHK#]-"):])
            
            # 排除存在未配对check的pattern
            # filter 1
            # if (do_filter):
            is_bad_pattern = False
            for check_func_pair_name in check_func_list:
                if check_func_pair_name not in pattern_list:
                    is_bad_pattern = True
            if is_bad_pattern:
                result["reason"] = "no check pair"
                # continue

            # 记录pattern出现过的函数名
            pattern_covered_func = set()
            for loc in locations:
                pattern_covered_func.add(sid2func_name[loc])
            if (do_ranking):
                if (len(pattern_covered_func) != support_filter):
                    continue

            # 在有check的pattern中,非check元素在其他位置是否未和check一起出现
            violation_slices = {}
            # tmp_vio_id = 1
            print("seeking violations")
            for word in pattern_list:
                for loc in word2sid[word]:
                    # 如果元素是在非pattern所在函数才继续
                    if sid2func_name[str(loc)] in pattern_covered_func:
                        continue
                    if check_only:
                        if has_func_check and not word.startswith("[#CHK#]-"):
                            for check, loc_list in check_loc_dict.items():
                                if loc not in loc_list:
                                    ret_func_name_list = sid2retlist[str(loc)]
                                    # 如果这个函数所在的那一行将该函数的返回值ret了，则跳过
                                    if word in ret_func_name_list:
                                        continue
                                    func_name = sid2func_name[str(loc)]
                                    if func_name not in violation_slices.keys():  
                                        violation_slices[func_name] = [[word, check]]
                                    else:
                                        violation_slices[func_name].append([word, check])
                    else:
                        if has_func_check and not word.startswith("[#CHK#]-"):
                            for check, loc_list in check_loc_dict.items():
                                if loc not in loc_list:
                                    ret_func_name_list = sid2retlist[str(loc)]
                                    # 在这里进行排除操作： 
                                    # 如果这个缺少的函数所在的那一行将该函数的返回值ret了，则跳过
                                    if word in ret_func_name_list:
                                        continue                                
                                    
                                    # 剩下的violation将被收集
                                    # slice_list的内容为：
                                    #       missing_pattern pattern缺失的部分
                                    #       vio_pattern 违反的slice全文
                                    #       covered_pattern 违例覆盖的pattern部分
                                    vio_func_name = sid2func_name[str(loc)]
                                    violation_slices[vio_func_name] = [list(set(pattern_list) - set(sid2slice[str(loc)].strip().split(" "))), 
                                                                    sid2slice[str(loc)].strip().split(" "), 
                                                                    list(set(pattern_list).intersection(set(sid2slice[str(loc)].strip().split(" "))))]

                        elif loc not in locations:
                            if loc not in violation_slices.keys():  
                                vio_func_name = sid2func_name[str(loc)]
                                violation_slices[vio_func_name] = [list(set(pattern_list) - set(sid2slice[str(loc)].strip().split(" "))), 
                                                                sid2slice[str(loc)].strip().split(" "), 
                                                                list(set(pattern_list).intersection(set(sid2slice[str(loc)].strip().split(" "))))]
        

            # 如果违例列表不为空，则统计需要嵌入的样本
            print("filter violations")
            if len(violation_slices) > 0:
                
                # 在这里筛选置信度
                if (do_ranking):
                    if (len(pattern_covered_func) != support_filter) or (len(violation_slices) > 2): 
                        continue

                vio_pattern_cover_dict = {}
                if len(violation_slices) == 2:
                    pass
                for vio_func_name, v in violation_slices.items(): 
                    cover_set = frozenset(v[2])
                    if cover_set not in vio_pattern_cover_dict.keys():
                        vio_pattern_cover_dict[cover_set] = 1
                    else:
                        vio_pattern_cover_dict[cover_set] += 1

                for vio_func_name, v in violation_slices.items():
                    copy_result = copy.deepcopy(result)
                    cover_set = frozenset(v[2])
                    vio_confidence = len(pattern_covered_func)/(len(pattern_covered_func) + vio_pattern_cover_dict[cover_set])
                    missing_pattern_part = v[0]
                    # 排除违例为缺失部分函数的定义的情况
                    if vio_func_name in missing_pattern_part:
                        continue
                    copy_result["func level support"] = len(pattern_covered_func)     
                    copy_result["func level confidence"] = vio_confidence
                    copy_result["pattern violation count"] = len(violation_slices)         
                    copy_result["violation info"] = [vio_func_name, v]
                    copy_result["pattern_covered_func"] = list(pattern_covered_func)
                    copy_result["vio_pattern_cover_rate"] = 1 - ( len(v[0]) / len(set(pattern_list)) )
                    
                    # 计算提升度：
                    if (not do_ranking):
                        
                        P_AB = len(pattern_covered_func)/slice_sum
                        P_A = (len(pattern_covered_func) + vio_pattern_cover_dict[cover_set])/slice_sum
                        # P_B
                        missing_part_locations_list = []
                        for missing_item in missing_pattern_part:
                            missing_part_locations_list.append(word2sid[missing_item])
                        
                        common_elements = set(missing_part_locations_list[0])
                        # 依次与其他列表求交集
                        for lst in missing_part_locations_list[1:]:
                            common_elements.intersection_update(lst)

                        P_B = len(common_elements)/slice_sum

                        copy_result["lift"] = P_AB/(P_A*P_B)

                        copy_result["all_conf"] = len(pattern_covered_func)/max((len(pattern_covered_func) + vio_pattern_cover_dict[cover_set]), len(common_elements))

                    # 收集pattern的上下文 
                    pattern_context_dict = {}
                    for sid in copy_result["locations"]:
                        # pattern_context_dict[sid2func_name[sid]] = " ".join(list(set(sid2slice[str(sid)].strip().split(" ")) - set(pattern_list)))
                        # no_pattern_sup_context = []
                        # for word in sid2slice[str(sid)].strip().split():
                        #     if word in pattern_list:
                        #         continue
                        #     no_pattern_sup_context.append(word)
                        # no_pattern_sup_context = " ".join(no_pattern_sup_context)
                        # pattern_context_dict[sid2func_name[sid]] = no_pattern_sup_context
                        pattern_context_dict[sid] = sid2slice[str(sid)].strip()
                    copy_result["pattern_context_dict"] = pattern_context_dict
                    
                    # 收集违例的上下文
                    # vio_context = " ".join(list(set(v[1]) - set(pattern_list)))
                    vio_context = " ".join(v[1])
                    # no_pattern_vio_context = []
                    # for word in v[1]:
                    #     if word in pattern_list:
                    #         continue
                    #     no_pattern_vio_context.append(word)
                    # no_pattern_vio_context = " ".join(no_pattern_vio_context)

                    copy_result["vio_context"] = vio_context
                    copy_result["vio_id"] = vio_id
                    # result["has_same_return"] = has_same_return

                    # 排除缺失部分是上下文中的相似函数进行功能替代的情况
                    if (do_filter):
                        filtered_missing_pattern_part = []
                        replaced_pattern = {}
                        for ms_word in missing_pattern_part:
                            # check不检查功能替代，只检查函数
                            if ms_word.startswith("[#CHK#]-"):
                                continue

                            has_similar_func = False
                            most_similar_dist = -1

                            ms_word_v = embed_word(we_item_model, ms_word, item_embedding_dict, has_item_embedded)
                            for vc_word in list(set(vio_context.strip().split()) - set(pattern_list)):
                                vc_word_v = embed_word(we_item_model, vc_word, item_embedding_dict, has_item_embedded)
                                # edit_distance = Levenshtein.distance(ms_word, vc_word)
                                edit_distance = util.cos_sim(ms_word_v, vc_word_v)
                                if edit_distance >= 0.95 and edit_distance > most_similar_dist:
                                    has_similar_func = True
                                    replaced_pattern[ms_word] = vc_word
                                    most_similar_dist = edit_distance
                            if not has_similar_func:
                                filtered_missing_pattern_part.append(ms_word)
                        # check不检查功能替代，只检查函数，但是，如果被替代的函数也有check，且替代的函数被检查过，则也应该没有问题。
                        # filter 2
                        for ms_word in missing_pattern_part:
                            if ms_word.startswith("[#CHK#]-"):
                                checked_func = ms_word[len("[#CHK#]-"):]
                                if checked_func in replaced_pattern.keys():
                                    replaced_check = "[#CHK#]-" + replaced_pattern[checked_func]
                                    if replaced_check in list(set(vio_context.strip().split()) - set(pattern_list)):
                                        replaced_pattern[ms_word] = replaced_check
                                        continue
                                filtered_missing_pattern_part.append(ms_word)

                        if len(filtered_missing_pattern_part) == 0:
                            copy_result["reason"] = "function replaced"
                        # continue
                    else:
                        filtered_missing_pattern_part = missing_pattern_part
                        replaced_pattern = {}

                    copy_result["filtered_missing_pattern_part"] = filtered_missing_pattern_part
                    copy_result["replaced_pattern"] = replaced_pattern

                    # 排除缺失部分超过一半的pattern违例
                    # filter 3
                    # if (do_filter):
                    if len(filtered_missing_pattern_part) > len(pattern_list)/2:
                        copy_result["reason"] = "missing more than half"
                            # continue

                    # 计算相似度分数
                    # result["rank_score"], result["nearlest_pattern"], result["nearlest_func_name"] = get_cos_similarity(se_model, vio_context, pattern_context_dict, se_model_dir, vio_id, context_embedding_dict, has_context_embedded)
                    # print("violation count: ", str(vio_id))
                    vio_id += 1
                    broken_pattern_list.append(copy_result)
                # for end
                # 为broken_pattern_list中的result添加必要信息
            # if end
        # for end
        # 获取到了broken_pattern_list
        with open(broken_pattern_list_file, "wb+") as bplf:
            pickle.dump(broken_pattern_list, bplf)
    # else end

    T_get_vio = time.time()


    # 对broken pattern list进行嵌入和计算相似度处理
    # 按照vio_id%128进行分组
    if (do_ranking):
        import math
        mult_num = 7
        total_batch_num = math.ceil(len(broken_pattern_list)/50)
        groups = defaultdict(list)
        for result in broken_pattern_list:
            vio_id = result["vio_id"]
            groups[vio_id % total_batch_num].append(result) 

        # 多进程
        from multiprocessing import Pool
        
        batch_id = 0
        broken_pattern_list = []

        while(batch_id != total_batch_num):
            print("preparing process")

            paralist = []
            for remainder in range(mult_num):
                
                sublist = groups.get(batch_id, [])
                para = [sublist, se_model, se_model_dir, we_funcname_model, 
                                        context_embedding_dict, has_context_embedded, funcname_embedding_dict, 
                                        has_funcname_embedded, sid2func_name, remainder]
                paralist.append(tuple(para))
                batch_id += 1
                if batch_id == total_batch_num:
                    break

            with Pool(processes=mult_num) as pool:  
                results = pool.starmap(process_list, paralist)
     
            for i in results:
                broken_pattern_list.extend(i)

    # 创建线程池并行处理   
    # print("preparing thread")
    # if (do_ranking):
    #     with concurrent.futures.ThreadPoolExecutor(max_workers=mult_num) as executor:
    #         # 准备任务（确保处理所有128个可能的余数）
    #         future_to_key = {}
    #         for remainder in range(mult_num):
    #             sublist = groups.get(remainder, [])
    #             future = executor.submit(process_list, sublist, se_model, se_model_dir, we_funcname_model, 
    #                                     context_embedding_dict, has_context_embedded, funcname_embedding_dict, 
    #                                     has_funcname_embedded, sid2func_name, remainder)
    #             future_to_key[future] = remainder

    #         # 收集并合并结果
    #         broken_pattern_list = []
    #         for future in concurrent.futures.as_completed(future_to_key):
    #             try:
    #                 broken_pattern_list.extend(future.result())
    #             except Exception as e:
    #                 print(f"处理余数 {future_to_key[future]} 时发生错误: {e}")

    T_end = time.time()

    if not has_context_embedded:
        with open(context_embedding_file, "wb+") as f:
            pickle.dump(context_embedding_dict, f)
    
    if not has_funcname_embedded:
        with open(funcname_embedding_file, "wb+") as f:
            pickle.dump(funcname_embedding_dict, f)
    
    if not has_funcname_embedded:
        with open(item_embedding_file, "wb+") as f:
            pickle.dump(item_embedding_dict, f)

    # broken_pattern_list = sorted(broken_pattern_list, key=lambda x:(x["func level support"], -x["pattern_length"], -x["min_vio_len"]), reverse=True)
    # broken_pattern_list = sorted(broken_pattern_list, key=lambda x:(x["func level support"], x["vio_pattern_cover_rate"], x["rank_score"]), reverse=True)

    if (do_ranking):
        broken_pattern_list = sorted(broken_pattern_list, key=lambda x:(x["rank_score"]), reverse=True)
    else:
        broken_pattern_list = sorted(broken_pattern_list, key=lambda x:(x["func level confidence"]), reverse=True)

    if check_only:
        with open(os.path.join(rules_result_dir, 'result-check_only.html'), 'w') as f:
            write_result(check_only, f, broken_pattern_list, do_filter, do_ranking)
    else:
        with open(result_file, 'w') as f:
            write_result(check_only, f, broken_pattern_list, do_filter, do_ranking)


    # with open(os.path.join(rules_result_dir, 'result.json'), 'w') as f:
    #     json.dump(broken_pattern_list, f, indent=4)
    


    print("get voilation:")
    print(T_get_vio - T_start)

    print("embedding, filtering, and ranking")
    print(T_end - T_get_vio)

    with open(os.path.join(rules_result_dir, str(support_filter)+"_time.txt"), 'w+') as f:
        f.write("get voilation:")
        f.write(str(T_get_vio - T_start))

        f.write("\nembedding, filtering, and ranking")
        f.write(str(T_end - T_get_vio))



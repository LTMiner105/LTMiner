import json
import os, re
from gensim.models import FastText
from gensim.test.utils import datapath

class WE_Model:
    def __init__(self, epoch=40, dim=100):
        self.epoch = epoch
        self.model = None

    def train(self, we_model_dir, mode):

        if mode == "func_name":
            corpus_file = datapath(os.path.join(we_model_dir, "we_train_data.txt"))
            #corpus_file = datapath('/home/osroot/api_sequences.txt')
        elif mode == "context":
            corpus_file = datapath(os.path.join(we_model_dir, "we_train_context_data.txt"))

        model = FastText(sg=1, min_count=2, workers=128, seed=1)

        model.build_vocab(corpus_file=corpus_file)

        total_words = model.corpus_total_words
        print("\nstart training....")
        model.train(corpus_file=corpus_file, total_words=total_words, epochs=5)
        print("saving the model...")
        model.save(os.path.join(we_model_dir, "FastText-WE_Model"))
        print("done\n")
    
    # 为了嵌入函数名，需要将ret和chk相关的词去除掉。
    def prepare_data(self, we_model_dir, original_file):
        if not os.path.exists(we_model_dir):
            os.mkdir(we_model_dir)

        with open(original_file, "r") as f:
            data_lines = f.readlines()
        
        train_data_lines = []
        for line in data_lines:
            if line.startswith("func_call--"):
                continue
            no_rtn_line = re.sub(r"\[#RT#\]\-\w* ", "", line)
            no_chk_line = re.sub(r"\[#CHK#\]\-\w* ", "", no_rtn_line)
            train_data_lines.append(no_chk_line)
        
        with open(os.path.join(we_model_dir, "we_train_data.txt"), "w+") as f:
            for line in train_data_lines:
                f.write(line)

    # 为了嵌入上下文，需要将ret相关的词去除掉。
    def prepare_context_data(self, we_model_dir, original_file):
        if not os.path.exists(we_model_dir):
            os.mkdir(we_model_dir)

        with open(original_file, "r") as f:
            data_lines = f.readlines()
        
        train_data_lines = []
        for line in data_lines:
            if line.startswith("func_call--"):
                continue
            no_rtn_line = re.sub(r"\[#RT#\]\-\w* ", "", line)
            train_data_lines.append(no_rtn_line)
        
        with open(os.path.join(we_model_dir, "we_train_context_data.txt"), "w+") as f:
            for line in train_data_lines:
                f.write(line)
    
    def load_model(self, we_model_dir):
        model = FastText.load(os.path.join(we_model_dir, "FastText-WE_Model"))
        self.model = model

    def embedding_single_word(self, target_word):
        return self.model.wv[target_word]
    

class SE_Model:
    def __init__(self, epoch=40, dim=300):
        self.epoch = epoch
        self.dim = dim

    def prepare_train_data(self, model_dir, original_file):
        if not os.path.exists(model_dir):
            os.mkdir(model_dir)
        if not os.path.exists(os.path.join(model_dir, "temp")):
            os.mkdir(os.path.join(model_dir, "temp"))

        with open(original_file, "r") as f:
            data_lines = f.readlines()
        
        train_data_lines = []
        count = 0
        for line in data_lines:
            if line.startswith("func_call--"):
                continue
            no_rtn_line = re.sub(r"\[#RT#\]\-\w* ", "", line)
            count += 1
            train_data_lines.append("__label__" + str(count) + " " + no_rtn_line)

        with open(os.path.join(model_dir, "se_train_data_set.txt"), "w+") as out_f:
            for line in train_data_lines:
                out_f.write(line)            

    def train(self, model_dir):
        train_sample_file = os.path.join(model_dir, "se_train_data_set.txt")
        model_config = os.path.join(model_dir, "PVDM_model") + " -epoch "\
                       + str(self.epoch) + " -dim " + str(self.dim)
        # if os.path.exists(model_dir):
        #     os.mkdir(model_dir)
        cmd = "cd ./fastText-PV\n./fasttext PVDM -input " + train_sample_file  + " -output " + model_config
        # print(cmd)
        os.system(cmd)

    def embed_single_seq(self, model_dir, target_seq, embed_batch=None):
        if not embed_batch:
            tmp_seq_file = "temp_seq.txt"
            tmp_vec_file_name = "temp_vec"
        else:
            tmp_seq_file = "temp_seq_" + str(embed_batch) + ".txt"
            tmp_vec_file_name = "temp_vec_" + str(embed_batch)

        target_temp_dir = os.path.join(model_dir, "temp", tmp_seq_file)
        with open(target_temp_dir, "w+") as f:
            f.write(target_seq)
        output_temp_dir = os.path.join(model_dir, "temp", tmp_vec_file_name)
        model_config = os.path.join(model_dir, "PVDM_model.bin")

        cmd = "cd ./fastText-PV && ./fasttext predictPVDM " + model_config \
              + " " + target_temp_dir + " " + output_temp_dir
        # print(cmd)
        os.system(cmd)
        with open(output_temp_dir + ".vec", "r+") as f:
            vec_text = f.read().strip().split(" ")

        return vec_text

    def embed_seq(self, target_dir, train_batch_name, output_dir, model_name, count=None):

        target_parents_dir = "/".join(target_dir.split("/")[:-1])
        output_parents_dir = "/".join(output_dir.split("/")[:-1])
        with open(target_dir, "r") as f:
            target_list = f.readlines()
        vec_list = []

        if count:
            tmp_txt_name = "temp_" + str(count) + ".txt"
            tmp_vec_name = "temp_" + str(count)
        else:
            tmp_txt_name = "temp.txt"
            tmp_vec_name = "temp"
        for i in target_list:
            with open(os.path.join(target_parents_dir, tmp_txt_name), "w+") as f:
                f.write(i)
            self.embed_single_seq(os.path.join(target_parents_dir, tmp_txt_name),
                             os.path.join(output_parents_dir, tmp_vec_name), train_batch_name, model_name)
            with open(os.path.join(output_parents_dir, tmp_vec_name + ".vec"), "r+") as f2:
                vec = f2.read()
                vec_list.append(vec)

        with open(output_dir + ".vec", "w+") as f:
            for vec in vec_list:
                f.write(vec)


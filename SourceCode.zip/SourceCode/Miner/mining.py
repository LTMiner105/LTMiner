import json
import subprocess
import os
import re

def text_to_numbers(original_file, rules_result_dir, input_file, min_support, max_support):
    # print(input_file)
    # 读取原始文本并创建词典
    # 同时记录每一个切片的id和func
    with open(original_file, 'r') as f:
        lines = f.readlines()

    # IDs are started from 0
    word2id = {}
    id2word = {}
    current_id = 0
    current_func_name = ""
    slice_id = 0
    numeric_seq = []
    sid2func_name = {}
    sid2retlist = {}
    func_name2sid = {}
    id2func_dict = {}
    rare_token_set = set()
    word2sid = {}
    sid2slice = {}

    for line in lines:
        words = line.strip().split()
        match = re.search(r"func_call--(\w+):", line)
        if match:
            current_func_name = match.group(1)
            continue
        
        for word in words:
            if word not in id2func_dict.keys():
                id2func_dict[word] = [current_func_name]
            elif current_func_name not in id2func_dict[word]:
                id2func_dict[word].append(current_func_name)

            if word not in word2id.keys():
                word2id[word] = current_id
                id2word[current_id] = word
                current_id += 1

    for word, func_list in id2func_dict.items():
        if min_support <= len(func_list) <= max_support:
            rare_token_set.add(word)

    for line in lines:
        words = line.strip().split()
        match = re.search(r"func_call--(\w+):", line)
        if match:
            current_func_name = match.group(1)
            continue
        
        # 通过func sup来过滤rare items，同时排除掉句子中的return
        rare_words = []
        ret_func_name_list = []
        line_without_rtn = []
        for word in words:
            if word.startswith("[#RT#]-"):
                ret_func_name_list.append(str(word[len("[#RT#]-"):]))
                continue
            if word in rare_token_set:
                rare_words.append(word)
            line_without_rtn.append(word)
        line_without_rtn = " ".join(line_without_rtn)

        sid2retlist[slice_id] = ret_func_name_list
        if len(rare_words) == 0:
            continue
        # 生成数字序列并保存
        temp_seq = [str(word2id[word]) + " " for word in rare_words]
        numeric_seq += list(set(temp_seq)) + ["\n"]
        sid2func_name[slice_id] = current_func_name
        if current_func_name not in func_name2sid.keys():
            func_name2sid[current_func_name] = [slice_id]
        else:
            func_name2sid[current_func_name].append(slice_id)
        
        # 记录每个词都出现在哪些事务钟

        for word in words:
            if word not in word2sid.keys():
                word2sid[word] = [slice_id]
            else:
                word2sid[word].append(slice_id)

        sid2slice[slice_id] = line_without_rtn
        slice_id += 1      

    # 保存词典
    with open(os.path.join(rules_result_dir, 'word2id.json'), 'w') as f:
        json.dump(word2id, f, indent=4)
    with open(os.path.join(rules_result_dir, 'id2word.json'), 'w') as f:
        json.dump(id2word, f, indent=4)
    with open(os.path.join(rules_result_dir, 'func_name2sid.json'), 'w') as f:
        json.dump(func_name2sid, f, indent=4)
    with open(os.path.join(rules_result_dir, 'sid2func_name.json'), 'w') as f:
        json.dump(sid2func_name, f, indent=4)
    with open(os.path.join(rules_result_dir, 'word2sid.json'), 'w') as f:
        json.dump(word2sid, f, indent=4)
    with open(os.path.join(rules_result_dir, 'sid2retlist.json'), 'w') as f:
        json.dump(sid2retlist, f, indent=4)
    with open(os.path.join(rules_result_dir, 'sid2slice.json'), 'w') as f:
        json.dump(sid2slice, f, indent=4)
    
    with open(input_file, 'w+') as f:
        f.write(''.join(numeric_seq))

def numbers_to_text(output_file, restored_file, rules_result_dir):
    # 读取生成的数字文件
    with open(output_file, 'r') as f:
        numeric_output_lines = f.readlines()

    # 加载词典
    with open(os.path.join(rules_result_dir, 'id2word.json'), 'r') as f:
        id2word = json.load(f)
    
    # 转换数字为字符串ID并转为单词
    id2word = {int(k): v for k, v in id2word.items()}  # 转换JSON的字符串key为int
    restored_list = []
    patterns_num = numeric_output_lines.pop(0)

    for numeric_output_line in numeric_output_lines:
        if len(numeric_output_line) == 0:
            continue
        numeric_output = numeric_output_line.strip().split()
        pattern_len = int(numeric_output.pop(0))
        pattern_sup = int(numeric_output.pop(0))
        location_list = numeric_output[-pattern_sup:]
        pattern = numeric_output[:-pattern_sup]
        restored_words = [id2word[int(num)] for num in pattern]
        result = {
            "pattern_length": pattern_len,
            "pattern_support": pattern_sup,
            "locations": location_list,
            "pattern": restored_words,
        }
        restored_list.append(result)

    # 保存最终结果
    with open(restored_file, 'w') as f:
        json.dump(restored_list, f, indent=4, ensure_ascii=False)
